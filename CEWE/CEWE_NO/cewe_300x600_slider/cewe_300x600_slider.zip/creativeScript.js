/**
  * Template Name
  * @Owner Name Developer
  * @Date
*/
function onLemonpiReady(cb) {
  if (cb) {
      var loadLemonpiTimerId = setInterval(function() {
          if (window.lemonpi) {
              clearInterval(loadLemonpiTimerId);
              cb();
          }
      }, 0);
  }
}


window.addEventListener('lemonpi.content/ready', event => {
console.clear();
  const content = event.detail.content
  const source = event.detail.source

  
  let product_container = document.getElementById("product_carousel");
  let creative = document.getElementById("creative_container");

  let image_1 = content.product_image_1.value;
  let image_2 = content.product_image_2.value;
  let image_3 = content.product_image_3.value;

  const images = [ image_1, image_2, image_3 ]
  let currentImageIndex = 1;

  let url_1 = content.url_destination.value;
  let url_2 = content.url_destination_2.value;
  let url_3 = content.url_destination_3.value;

  const urls = [url_1, url_2, url_3]

  var leftDirectionVar = 300; // Controlls the slider value, on how much it should move the images.

  $('#copy_1_text').html(content.copy_1_text.value)  
  $('#copy_2_text').html(content.copy_2_text.value) 
  $('#copy_3_text').html(content.copy_3_text.value)  

  $('#logo_image').css({
      content: 'url('+ content.logo_image.value + ')',
  });

  
  $('#arrow_left, #arrow_right').click(onArrowClick)

for (let i = 1; i < 4; i++) {
  if (i == 3) {
    $("<div>", {
      'html': content.slide_3_text.value,
      'class': "product_" + i + ' product_image' ,
      css: {
        'font-family': 'CEWE',
        'font-size':'19px',
        'color':'white',
        'text-align':'center',
        'top':'170px',
        'left': 30 + (i-1)* (leftDirectionVar) + 'px',
        'width': '240px',
      },
    }).appendTo(product_container);
  } else if (i == 1) {
    $("<div>", {
      'class': "product_" + i + ' product_image' ,
      css: {
          content: 'url('+ images[i-1] + ')',
          'background-repeat': 'no-repeat',
          'background-position': 'center center',
          'position' : 'absolute',
          'left': 30 + (i-1)* (leftDirectionVar) + 'px',
          'top':'110px',
          'height':'200px',
          'width': '240px',
      },
    }).appendTo(product_container);
  } else {
    $("<div>", {
      'class': "product_" + i + ' product_image' ,
      css: {
          content: 'url('+ images[i-1] + ')',
          'background-repeat': 'no-repeat',
          'background-position': 'center center',
          'position' : 'absolute',
          'background-size': 'contain',
          'left': 50 + (i-1)* (leftDirectionVar) + 'px',
          'top':'120px',
          'height':'240px',
          'width': '240px',
      },
    }).appendTo(product_container);
  }
}

$("<div>", {
  'class':"world_click",
  'id':"world_click",
  css: {
    'width': '100%',
    'height': '100%',
    'position': 'relative',
    'z-index':'0',
  },
}).appendTo(creative);


function onArrowClick(event) {
  var direction = event.currentTarget.id === 'arrow_left' ? '+=' : '-=';
  var goAhead = false;
  
  if (direction == "+=" && currentImageIndex > 1) {
    currentImageIndex--;
    goAhead = true;
  } else if (direction == "-=" && currentImageIndex < 3) {
    currentImageIndex++;
    goAhead = true;
  }
  if (goAhead) {
    
    function goBackTostart (currentIndex, direction) {
      if (currentIndex === 3 && direction =='-='){
        var tl = new TimelineMax();
        tl.to(".product_image", 0.7, { left: direction + (-leftDirectionVar*2), ease: Power1.easeInOut, delay: 2.2}, 0)
      }else{
  
      }
    }

    var tl = new TimelineMax({});

    tl.to(".product_image", 0.7, { left: direction + leftDirectionVar, ease: Power1.easeInOut}, 0)
    .call(goBackTostart,[currentImageIndex, direction], null,tl.duration())
    tl.to(".product_image", 0.7, { left: direction + leftDirectionVar, ease: Power1.easeInOut}, 9)
    .call(goBackTostart,[currentImageIndex, direction], null,tl.duration())
    tl.to(".product_image", 0.7, { left: direction + leftDirectionVar, ease: Power1.easeInOut}, 18)
    .call(goBackTostart,[currentImageIndex, direction], null,tl.duration())
    tl.to(".product_image", 0.7, { left: direction + leftDirectionVar, ease: Power1.easeInOut}, 27)
  }
  
}

// Click event handler for the "world_click" div
document.getElementById('world_click').onclick = function (event) {

  // Retrieve the URL from the data attribute of the currently displayed product image
  var currentURL = document.querySelector('div.product_'+currentImageIndex+'.product_image').getAttribute('data-url');

  var carousel_element = event.srcElement.nextElementSibling;
  var slider_element_1_left_value = carousel_element.querySelector(".product_1").style.left;
  //console.log(slider_element_1_left_value);
  if(parseInt(slider_element_1_left_value) == 30) {
    currentURL = url_1;
  } else if (parseInt(slider_element_1_left_value) == -270) {
    currentURL = url_2;
  } else {
    currentURL = url_3;
  }

  // Open the URL
 window.open(currentURL, '_blank');
};

  // document.getElementById('world_click').onclick = () =>
  //       window.dispatchEvent(
  //           new CustomEvent('lemonpi.interaction/click', {
  //           detail: {
  //               placeholder: ['url_destination'],
  //           }
  //       })
  //   );

  $('#content')
  .on('mouseenter touchstart', onUserEnter)
  .on('mouseleave touchend', onUserLeave)

  function onUserEnter(event) {
    autoSwipeAnimation.stop();
  }
  function onUserLeave(event) {
    autoSwipeAnimation.restart();
  }
    
  function playAutoSwipeAnimation() {
    $("#arrow_right").click();
  }

  TweenMax.set('#copy_2_text', { autoAlpha:0 });
  TweenMax.set('#copy_3_text', { autoAlpha:0 });

  var autoSwipeAnimation = new TimelineMax({ repeat: -1 })
  .add(playAutoSwipeAnimation, 3)

var textAnimation = new TimelineMax({repeat:-1})
  .fromTo('#copy_1_text', 0.7, { autoAlpha:0 }, { autoAlpha: 1 }) 
  .to('#copy_1_text', 0.7, { autoAlpha:0, delay: 2}) 
  .to('#copy_2_text', 0.7, { autoAlpha:1}) 
  .to('#copy_2_text', 0.7, { autoAlpha:0, delay:1.5})
  .to('#copy_3_text', 0.7, { autoAlpha:1}) 
  .to('#copy_3_text', 0.7, { autoAlpha:0, delay:1.5}) 
  
  })